Order *d = new Deploy(nullptr, 1);
        // d->execute();//Execute a deploy command
        // Order *a = new Advance(nullptr, 2);
        // a->execute();//Execute a advance command
        // Order *bl = new Blockade(nullptr, 3);
        // bl->execute();//Execute a blockade command
        // Order *b = new Bomb(nullptr, 4);
        // b->execute();//Execute a bomb command
        // Order *al = new Airlift(nullptr, 5);
        // al->execute();//Execute a airlift command
        // Order *n = new Negotiate(nullptr, 6);
        // n->execute();//Execute a negotiate command