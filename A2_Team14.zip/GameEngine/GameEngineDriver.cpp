#include "GameEngine.cpp"

int main() {

    GameEngine gameEng;

    gameEng.startupPhase();

    return 0;
}