#include "GameEngine.cpp"

int main() {

    GameEngine gameEng;

    gameEng.start();

    return 0;
}