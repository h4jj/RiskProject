#include "Map.h"
#include "Map.cpp"

int main() {

    Map mapObject;
    Territory* country1 = new Territory("Lebanon", "Asia");
    Territory* country2 = new Territory("Jordan", "Asia");
    Territory* country3 = new Territory("Syria", "Asia");

    Edge* edge1 = new Edge(country1, country2);

    mapObject.Nodes.push_back(country1);
    mapObject.Nodes.push_back(country2);
    mapObject.Nodes.push_back(country3);

    mapObject.Edges.push_back(edge1);

    return 0;
}