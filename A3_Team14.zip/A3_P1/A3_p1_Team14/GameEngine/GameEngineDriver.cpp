#include "GameEngine.cpp"
#include "PlayerStrategies.cpp"

int main() {

    GameEngine gameEng;
    gameEng.startupPhase();

    // Player* player = new Player("Ahmad");
    // HumanPlayerStrategy* hps = new HumanPlayerStrategy();
    // player->ps = hps;
    // hps->p = player;
    // player->issueOrder(player->ps);

    return 0;
}